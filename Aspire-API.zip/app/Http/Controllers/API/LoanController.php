<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use App\Models\User;
use App\Models\Loan;
use App\Models\LoanDetail;
use Auth;
use Carbon\Carbon;

class LoanController extends Controller
{
    public function requestLoan(Request $request)
    {
        $validator = validator::make($request->all(),
        [
            
            'amount' => ['required', 'numeric', 'min:0', 
            function ($attribute, $value, $fail) {
                $value = floatval($value);
    
                if ($value < 0 || $value >= 1e12) {
                    $fail($attribute . ' is invalid');
                }
            } ],
            'term' => 'required|integer|min:1',
            'date' => 'nullable|date|date_format:Y-m-d|after_or_equal:today'
            
        ]);
        
        if($validator->fails())
        {
            $response = [
                'success' => false,
                'message' => $validator->errors()
            ];

            return response()->json($response, 400);
        }
        $input = $request->all();
        $input['date']=$input['date']?? date('Y-m-d');
        $input['user_id'] = Auth::user()->id;
        $Loan = Loan :: create($input);
        $loanDetails = [];
        
        for($i = 1;$i<=$input['term'];$i++)
        {
            if($i==$input['term']){
                $amount[$i]=$input['amount']-array_sum($amount);
            }
            else{
            $amount[$i]=round($input['amount']/3,2);
            }
            $input['scheduled_payment_date'][$i]= date('Y-m-d',strtotime("+".(7)*($i)." day", strtotime($input['date'])));
            $loanDetails[] = new LoanDetail([
                $Loan->getKey(),
                'scheduled_payment_date' => $input['scheduled_payment_date'][$i],
                'amount' =>$amount[$i]
            ]);
            $Loan->loanDetail()->saveMany($loanDetails);
        }
        
         return response()->json($Loan, 200);
    }
    
}
