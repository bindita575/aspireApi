<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Loan;

class AdminLoanController extends Controller
{
    public function approveLoan()
    {
        
    }
    public function pendingLoan()
    {
        $response['data'] = Loan :: where('status','PENDING')->get();
        $response['total_record'] = count($response['data']);
         return response()->json($response, 200);
    }
}
