<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use app\Models\LoanDetail;

class Loan extends Model
{
    use HasFactory;
    protected $fillable = [
        'amount',
        'term',
        'user_id',
    ];
    public function loanDetail()
    {
        return $this->hasOne(LoanDetail::class);
    }
}
